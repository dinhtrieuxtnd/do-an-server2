import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common'
import { HashingService } from 'src/shared/services/hashing.service'
import { SharedUserRepo } from 'src/shared/repos/shared-user.repo'
import { ChangePasswordReqType } from './users.type'

@Injectable()
export class UsersService {
  constructor(
    private readonly hashingService: HashingService,
    private readonly sharedUserRepo: SharedUserRepo,
  ) {}

  async changePassword(body: ChangePasswordReqType): Promise<{ message: string }> {
    const user = await this.sharedUserRepo.findUnique({ email: body.email })
    if (!user) throw new NotFoundException('Người dùng không tồn tại')

    // // DEBUG: xem đang connect DB nào và user nào
    // // (log này chỉ để debug, xong việc thì xoá)
    console.log('[CHANGE-PASS] DB =', process.env.DATABASE_URL)
    console.log('[CHANGE-PASS] userId =', user.id, 'email =', user.email)
    const ok = await this.hashingService.compare(body.currentPassword, user.passwordHash)
    console.log('[CHANGE-PASS] compare(currentPassword, hash) =', ok)
    if (!ok) throw new BadRequestException('Mật khẩu hiện tại không đúng')

    const newHash = await this.hashingService.hash(body.newPassword)
    await this.sharedUserRepo.update({ id: user.id }, { passwordHash: newHash })

    return { message: 'Đổi mật khẩu thành công' }
  }
}
